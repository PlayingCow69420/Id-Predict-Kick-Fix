/*    */ package ceptea.serverTweaks;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerKickEvent;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public final class ServerTweaks
/*    */   extends JavaPlugin
/*    */   implements Listener {
/*    */   public void onEnable() {
/* 14 */     Bukkit.getPluginManager().registerEvents(this, (Plugin)this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDisable() {}
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onKick(PlayerKickEvent e) {
/* 24 */     if (e.getPlayer().isBanned()) {
/*    */       return;
/*    */     }
/* 27 */     if (e.getReason().equals("Cannot interact with self!")) {
/* 28 */       e.setCancelled(true);
/*    */     }
/*    */     
/* 31 */     if (e.getReason().toLowerCase().contains("invalid"))
/* 32 */       e.setCancelled(true); 
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\ServerTweaks-1.0-SNAPSHOT (2).jar!\ceptea\serverTweaks\ServerTweaks.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */